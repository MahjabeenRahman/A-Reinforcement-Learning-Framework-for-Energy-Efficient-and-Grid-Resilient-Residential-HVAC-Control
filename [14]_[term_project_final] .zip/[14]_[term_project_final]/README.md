# CSE 407 — Green Computing | Group 14 | Final Term Report

## Files

| File | Purpose |
|------|---------|
| `main.tex` | Main LaTeX source (IEEEtran two-column format) |
| `references.bib` | BibTeX bibliography (30+ entries) |
| `figures/generate_figures.py` | Python script to regenerate all figures |
| `figures/fig2_pmv_comparison.pdf` | PMV timeseries comparison |
| `figures/fig3_switching_freq.pdf` | Switching frequency bar chart |
| `figures/fig4_action_dist.pdf` | HVAC action distribution |
| `figures/fig5_robustness.pdf` | Robustness vs noise analysis |
| `figures/fig6_maddpg_zones.pdf` | MADDPG multi-zone trajectories |
| `figures/fig7_energy_comparison.pdf` | Energy consumption bar chart |
| `figures/fig8_ranking.pdf` | Multi-objective ranking |

## Compilation

### Step 1 — Download IEEEtran class
```bash
wget https://raw.githubusercontent.com/IEEEtran/IEEEtran/master/IEEEtran.cls
```

### Step 2 — Regenerate figures (run in Colab after evaluation)
Replace the placeholder arrays in `generate_figures.py` with your actual Colab
variables (`sac_pmv`, `ppo_pmv`, `td3_pmv`, `maddpg_pmv`, etc.) then run:
```bash
python figures/generate_figures.py
```

### Step 3 — Compile LaTeX
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```
Or use Overleaf: upload all files, set compiler to **pdfLaTeX**.

## IMPORTANT: Verify the ScienceDirect Reference

The entry `Salimi2024` in `references.bib` is a **placeholder** for:
> https://www.sciencedirect.com/science/article/abs/pii/S0196890424009361

Open that URL and update the `author`, `title`, `volume`, `pages`, and `doi`
fields in `references.bib` before submission.

## Submission ZIP Name
```
14_term_project_final.zip
```

## GitHub Repository
https://github.com/MahjabeenRahman/A-Reinforcement-Learning-Framework-for-Energy-Efficient-and-Grid-Resilient-Residential-HVAC-Control
