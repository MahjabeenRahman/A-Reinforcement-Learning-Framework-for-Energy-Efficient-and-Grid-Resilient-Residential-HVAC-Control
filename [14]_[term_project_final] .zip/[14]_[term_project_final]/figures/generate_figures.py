"""
generate_figures.py
===================
Run this script in the same Colab session AFTER evaluating all four
algorithms (SAC, PPO, TD3, MADDPG).  It saves publication-quality PDF
figures into this folder for the LaTeX report.

Required variables (already in Colab globals after evaluation):
  sac_pmv, ppo_pmv, td3_pmv, maddpg_pmv
  sac_actions, ppo_actions, td3_actions, maddpg_actions
  sac_switch, ppo_switch, td3_switch, maddpg_switch
  noise_levels, sac_robustness, ppo_robustness, td3_robustness
  agent_ids  (list of 5 zone names for MADDPG)
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")          # non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import os

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
DPI = 200

# ── colour palette (colourblind-friendly) ────────────────────────────
SAC_C   = "#0077BB"
PPO_C   = "#EE7733"
TD3_C   = "#009988"
MADD_C  = "#CC3311"
ZONE_CS = ["#0077BB", "#EE7733", "#009988", "#CC3311", "#AA3377"]

def savefig(name):
    path = os.path.join(OUT_DIR, name)
    plt.savefig(path, dpi=DPI, bbox_inches="tight")
    plt.close()
    print(f"Saved: {path}")


# ====================================================================
# Figure 1 — Methodology pipeline (static diagram — see LaTeX source)
# ====================================================================
# This figure is hand-drawn in TikZ in the LaTeX source.
# No Python output needed.


# ====================================================================
# Figure 2 — PMV comparison timeseries
# ====================================================================
def fig2_pmv(sac_pmv, ppo_pmv, td3_pmv, maddpg_pmv, n_show=1000):
    steps = np.arange(n_show)
    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.plot(steps, sac_pmv[:n_show],   lw=0.8, color=SAC_C,   label="SAC",    alpha=0.9)
    ax.plot(steps, ppo_pmv[:n_show],   lw=0.8, color=PPO_C,   label="PPO",    alpha=0.8)
    ax.plot(steps, td3_pmv[:n_show],   lw=0.8, color=TD3_C,   label="TD3",    alpha=0.8)
    ax.plot(steps, maddpg_pmv[:n_show], lw=0.8, color=MADD_C, label="MADDPG", alpha=0.8,
            linestyle="--")
    ax.axhline( 0.5, ls=":", color="gray", lw=1.2, label="±0.5 boundary")
    ax.axhline(-0.5, ls=":", color="gray", lw=1.2)
    ax.axhline( 0.0, ls="-", color="black", lw=0.6, alpha=0.4)
    ax.set_xlabel("Environment Step")
    ax.set_ylabel("PMV")
    ax.set_title("Thermal Comfort Comparison — PMV (first 1,000 steps)")
    ax.legend(fontsize=8, ncol=2, loc="upper right")
    ax.set_ylim(-3.0, 3.5)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    savefig("fig2_pmv_comparison.pdf")


# ====================================================================
# Figure 3 — Switching frequency bar chart
# ====================================================================
def fig3_switch(sac_switch, ppo_switch, td3_switch, maddpg_switch):
    labels  = ["SAC", "PPO", "TD3", "MADDPG"]
    values  = [sac_switch, ppo_switch, td3_switch, maddpg_switch]
    colours = [SAC_C, PPO_C, TD3_C, MADD_C]

    fig, ax = plt.subplots(figsize=(5, 3.5))
    bars = ax.bar(labels, values, color=colours, edgecolor="white", linewidth=0.5)
    for bar, v in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.001,
                f"{v:.4f}", ha="center", va="bottom", fontsize=8)
    ax.set_ylabel("Mean Switching Frequency")
    ax.set_title("HVAC Control Switching Frequency Comparison")
    ax.grid(axis="y", alpha=0.3)
    ax.set_ylim(0, max(values) * 1.20)
    fig.tight_layout()
    savefig("fig3_switching_freq.pdf")


# ====================================================================
# Figure 4 — HVAC action distribution (Living zone)
# ====================================================================
def fig4_action_dist(sac_actions, ppo_actions, td3_actions, maddpg_actions):
    fig, ax = plt.subplots(figsize=(6, 3.5))
    kw = dict(bins=35, alpha=0.55, density=True)
    ax.hist(sac_actions[:, 0],    color=SAC_C,  label="SAC",    **kw)
    ax.hist(ppo_actions[:, 0],    color=PPO_C,  label="PPO",    **kw)
    ax.hist(td3_actions[:, 0],    color=TD3_C,  label="TD3",    **kw)
    ax.hist(maddpg_actions[:, 0], color=MADD_C, label="MADDPG", linestyle="--", **kw)
    ax.set_xlabel("Living Zone HVAC Setpoint Action  (normalised)")
    ax.set_ylabel("Density")
    ax.set_title("HVAC Action Distribution — Four RL Controllers")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    savefig("fig4_action_dist.pdf")


# ====================================================================
# Figure 5 — Robustness analysis
# ====================================================================
def fig5_robustness(noise_levels, sac_rob, ppo_rob, td3_rob):
    fig, ax = plt.subplots(figsize=(6, 3.5))
    ax.plot(noise_levels, sac_rob, "o-", color=SAC_C, label="SAC")
    ax.plot(noise_levels, ppo_rob, "s-", color=PPO_C, label="PPO")
    ax.plot(noise_levels, td3_rob, "^-", color=TD3_C, label="TD3")
    ax.set_xlabel("Observation Noise  σ")
    ax.set_ylabel("Comfort Violation Rate (%)")
    ax.set_title("Robustness Against Measurement Uncertainty")
    ax.yaxis.set_major_formatter(mtick.PercentFormatter(decimals=0))
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    savefig("fig5_robustness.pdf")


# ====================================================================
# Figure 6 — MADDPG multi-zone action trajectories
# ====================================================================
def fig6_maddpg_zones(maddpg_actions, agent_ids, n_show=500):
    fig, ax = plt.subplots(figsize=(7, 3.5))
    for i, (agent, colour) in enumerate(zip(agent_ids, ZONE_CS)):
        if i < maddpg_actions.shape[1]:
            ax.plot(maddpg_actions[:n_show, i], lw=0.7,
                    color=colour, label=agent.capitalize())
    ax.set_xlabel("Simulation Step")
    ax.set_ylabel("HVAC Setpoint Action  (normalised)")
    ax.set_title("MADDPG Multi-Zone HVAC Control (first 500 steps)")
    ax.legend(fontsize=8, ncol=3, loc="upper right")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    savefig("fig6_maddpg_zones.pdf")


# ====================================================================
# Figure 7 — Energy comparison bar chart (SAC / PPO / TD3)
# ====================================================================
def fig7_energy(energy_dict):
    """energy_dict = {"SAC": X, "PPO": Y, "TD3": Z} in kWh"""
    labels  = list(energy_dict.keys())
    values  = list(energy_dict.values())
    colours = [SAC_C, PPO_C, TD3_C]

    fig, ax = plt.subplots(figsize=(5, 3.5))
    bars = ax.bar(labels, values, color=colours, edgecolor="white")
    for bar, v in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 3,
                f"{v:.1f}", ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Total HVAC Energy (kWh)")
    ax.set_title("HVAC Energy Consumption — 5,000 Evaluation Steps")
    ax.set_ylim(0, max(values) * 1.15)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    savefig("fig7_energy_comparison.pdf")


# ====================================================================
# Figure 8 — Multi-objective ranking (radar / bar)
# ====================================================================
def fig8_ranking(scores_dict):
    """scores_dict = {"SAC": 0.847, "TD3": 0.612, "PPO": 0.389}"""
    labels  = list(scores_dict.keys())
    values  = list(scores_dict.values())
    colours = [SAC_C, TD3_C, PPO_C]

    fig, ax = plt.subplots(figsize=(5, 3.5))
    bars = ax.barh(labels, values, color=colours, edgecolor="white")
    for bar, v in zip(bars, values):
        ax.text(v + 0.01, bar.get_y() + bar.get_height() / 2,
                f"{v:.3f}", va="center", fontsize=9)
    ax.set_xlabel("Multi-Objective Score  (higher = better)")
    ax.set_title("Aggregated Multi-Objective Ranking\n"
                 "(40% Energy + 40% Comfort + 20% Switching)")
    ax.set_xlim(0, 1.10)
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    savefig("fig8_ranking.pdf")


# ====================================================================
# MAIN — call from Colab after all variables are available
# ====================================================================
if __name__ == "__main__":
    # ----------------------------------------------------------------
    # Replace with your actual Colab variables, e.g.:
    #   fig2_pmv(sac_pmv, ppo_pmv, td3_pmv, maddpg_pmv)
    # Below we use placeholder arrays so the script is self-contained
    # for testing the figure aesthetics.
    # ----------------------------------------------------------------
    np.random.seed(42)
    N = 5000

    # Synthetic placeholder data (replace with real Colab outputs)
    _sac_pmv  = np.clip(np.random.normal(0.43, 0.45, N), -2.5, 3.5)
    _ppo_pmv  = np.clip(np.random.normal(0.58, 0.65, N), -2.5, 3.5)
    _td3_pmv  = np.clip(np.random.normal(0.51, 0.55, N), -2.5, 3.5)
    _madd_pmv = np.clip(np.random.normal(0.47, 0.50, N), -2.5, 3.5)

    _sac_act  = np.clip(np.random.normal(0.20, 0.30, (N, 1)), -1, 1)
    _ppo_act  = np.clip(np.random.beta(0.5, 0.5, (N, 1)) * 2 - 1, -1, 1)
    _td3_act  = np.clip(np.random.normal(0.15, 0.35, (N, 1)), -1, 1)
    _madd_act = np.clip(np.random.normal(0.10, 0.28, (N, 5)), -1, 1)

    _noise = [0.00, 0.02, 0.05, 0.10, 0.20]
    def _viol(pmv, s): 
        return 100 * np.mean(np.abs(pmv + np.random.normal(0,s,len(pmv))) > 0.5)
    _sac_r  = [_viol(_sac_pmv,  s) for s in _noise]
    _ppo_r  = [_viol(_ppo_pmv,  s) for s in _noise]
    _td3_r  = [_viol(_td3_pmv,  s) for s in _noise]

    fig2_pmv(_sac_pmv, _ppo_pmv, _td3_pmv, _madd_pmv)
    fig3_switch(0.0623, 0.0891, 0.0744, 0.1823)
    fig4_action_dist(_sac_act, _ppo_act, _td3_act, _madd_act)
    fig5_robustness(_noise, _sac_r, _ppo_r, _td3_r)
    fig6_maddpg_zones(_madd_act,
                      ["living", "kitchen", "bedroom01", "bedroom02", "bedroom03"])
    fig7_energy({"SAC": 487.3, "PPO": 568.1, "TD3": 523.7})
    fig8_ranking({"SAC": 0.847, "TD3": 0.612, "PPO": 0.389})

    print("\nAll figures generated successfully.")
    print("Copy the figures/ folder alongside main.tex and compile with:")
    print("  pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex")
